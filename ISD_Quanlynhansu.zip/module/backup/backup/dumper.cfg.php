<?php
$this->SET = array(
'last_action' => '0',
'last_db_backup' => 'quanlynhansu',
'tables' => '',
'comp_method' => '1',
'comp_level' => '9',
'last_db_restore' => 'joomusic1',
'tables_exclude' => '0',
)
?>