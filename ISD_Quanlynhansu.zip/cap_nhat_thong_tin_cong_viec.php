<?php
$ma_nv = $_GET['catID'];
if (!function_exists("GetSQLValueString")) {
    function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
    {
        if (PHP_VERSION < 6) {
            $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
        }

        $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

        switch ($theType) {
            case "text":
            $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
            break;    
            case "long":
            case "int":
            $theValue = ($theValue != "") ? intval($theValue) : "NULL";
            break;
            case "double":
            $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
            break;
            case "date":
            $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
            break;
            case "defined":
            $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
            break;
        }
        return $theValue;
    }
}

$editFormAction = htmlspecialchars($_SERVER["PHP_SELF"]);
if (isset($_SERVER['QUERY_STRING'])) {
    $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_POST["MM_update"])) && ($_POST["MM_update"] == "form1")) {
    $updateSQL = sprintf("UPDATE tlb_congviec SET ngay_vao_lam=%s, phong_ban_id=%s, cong_viec_id=%s, chuc_vu_id=%s, muc_luong_cb=%s, he_so=%s, phu_cap=%s, so_sld=%s, ngay_cap=%s, noi_cap=%s, tknh=%s, ngan_hang=%s, hoc_van_id=%s, bang_cap_id=%s, ngoai_ngu_id=%s, tin_hoc_id=%s, dan_toc_id=%s, quoc_tich_id=%s, ton_giao_id=%s, tinh_thanh_id=%s WHERE ma_nhan_vien=%s",
        GetSQLValueString($_POST['ngay_vao_lam'], "date"),
        GetSQLValueString($_POST['phong_ban_id'], "text"),
        GetSQLValueString($_POST['cong_viec_id'], "text"),
        GetSQLValueString($_POST['chuc_vu_id'], "text"),
        GetSQLValueString($_POST['muc_luong_cb'], "text"),
        GetSQLValueString($_POST['he_so'], "text"),
        GetSQLValueString($_POST['phu_cap'], "text"),
        GetSQLValueString($_POST['so_sld'], "text"),
        GetSQLValueString($_POST['ngay_cap'], "date"),
        GetSQLValueString($_POST['noi_cap'], "text"),
        GetSQLValueString($_POST['tknh'], "text"),
        GetSQLValueString($_POST['ngan_hang'], "text"),
        GetSQLValueString($_POST['hoc_van_id'], "text"),
        GetSQLValueString($_POST['bang_cap_id'], "text"),
        GetSQLValueString($_POST['ngoai_ngu_id'], "text"),
        GetSQLValueString($_POST['tin_hoc_id'], "text"),
        GetSQLValueString($_POST['dan_toc_id'], "text"),
        GetSQLValueString($_POST['quoc_tich_id'], "text"),
        GetSQLValueString($_POST['ton_giao_id'], "text"),
        GetSQLValueString($_POST['tinh_thanh_id'], "text"),
        GetSQLValueString($_POST['ma_nhan_vien'], "text"));
    $mydb->setQuery($updateSQL);
    $result = $mydb->executeQuery();
    $updateGoTo = "danh_sach_nhan_vien.php";
    if (isset($_SERVER['QUERY_STRING'])) {
        $updateGoTo .= (strpos($updateGoTo, '?')) ? "&" : "?";
        $updateGoTo .= $_SERVER['QUERY_STRING'];
    }
    sprintf("location: %s", $updateGoTo);
}
$mydb->setQuery("SELECT * FROM tlb_congviec where ma_nhan_vien = '$ma_nv'");
$RCcapnhat_congviec = $mydb->executeQuery();
$row_RCcapnhat_congviec = $mydb->fetch_assoc($RCcapnhat_congviec);
$totalRows_RCcapnhat_congviec = $mydb->num_rows($RCcapnhat_congviec);

if ($totalRows_RCcapnhat_congviec==0)
{
    $url = "index.php?require=them_moi_cong_viec.php&catID=$ma_nv&title=Thêm mới công việc";
    location($url);
}
$mydb->setQuery("SELECT * FROM tlb_phongban inner join tlb_congviec on tlb_phongban.phong_ban_id = tlb_congviec.phong_ban_id where tlb_congviec.ma_nhan_vien = '$ma_nv'");
$RCphongban1 = $mydb->executeQuery();
$row_RCphongban1 = $mydb->fetch_assoc($RCphongban1);
$totalRows_RCphongban1 = $mydb->num_rows($RCphongban1);

// Lấy danh sách sau khi phòng ban cập nhật
$mydb->setQuery("SELECT * FROM tlb_phongban");
$RCphongban = $mydb->executeQuery();
$row_RCphongban = $mydb->fetch_assoc($RCphongban);
$totalRows_RCphongban = $mydb->num_rows($RCphongban);

// Lấy công việc hiện tại
$mydb->setQuery("SELECT * FROM tlb_ctcongviec inner join tlb_congviec on tlb_ctcongviec.cong_viec_id = tlb_congviec.cong_viec_id where tlb_congviec.ma_nhan_vien = '$ma_nv'");
$RCctcongviec1 = $mydb->executeQuery();
$row_RCctcongviec1 = $mydb->fetch_assoc($RCctcongviec1);
$totalRows_RCctcongviec1 = $mydb->num_rows($RCctcongviec1);

// Lấy danh sách công việc sau khi cập nhật
$mydb->setQuery("SELECT * FROM tlb_ctcongviec");
$RCctcongviec = $mydb->executeQuery();
$row_RCctcongviec = $mydb->fetch_assoc($RCctcongviec);
$totalRows_RCctcongviec = $mydb->num_rows($RCctcongviec);

// Lấy danh sách chức vụ hiện tại
$mydb->setQuery("SELECT * FROM tlb_chucvu inner join tlb_congviec on tlb_chucvu.chuc_vu_id = tlb_congviec.chuc_vu_id where tlb_congviec.ma_nhan_vien = '$ma_nv'");
$RCChucvu1 = $mydb->executeQuery();
$row_RCChucvu1 = $mydb->fetch_assoc($RCChucvu1);
$totalRows_RCChucvu1 = $mydb->num_rows($RCChucvu1);

// Lấy danh sách chức vụ sau khi cập nhật
$mydb->setQuery("SELECT * FROM tlb_chucvu");
$RCChucvu = $mydb->executeQuery();
$row_RCChucvu = $mydb->fetch_assoc($RCChucvu);
$totalRows_RCChucvu = $mydb->num_rows($RCChucvu);

// Lấy danh sách học vấn hiện tại
$mydb->setQuery("SELECT * FROM tlb_hocvan inner join tlb_congviec on tlb_hocvan.hoc_van_id = tlb_congviec.hoc_van_id where tlb_congviec.ma_nhan_vien = '$ma_nv'");
$RCHocvan1 = $mydb->executeQuery();
$row_RCHocvan1 = $mydb->fetch_assoc($RCHocvan1);
$totalRows_RCHocvan1 = $mydb->num_rows($RCHocvan1);

// Lấy danh sách học vấn sau cập nhật
$mydb->setQuery("SELECT * FROM tlb_hocvan");
$RCHocvan = $mydb->executeQuery();
$row_RCHocvan = $mydb->fetch_assoc($RCHocvan);
$totalRows_RCHocvan = $mydb->num_rows($RCHocvan);

// Lấy danh sách bằng cấp hiện tại
$mydb->setQuery("SELECT * FROM tlb_bangcap inner join tlb_congviec on tlb_bangcap.bang_cap_id = tlb_congviec.bang_cap_id where tlb_congviec.ma_nhan_vien = '$ma_nv'");
$RCBangcap1 = $mydb->executeQuery();
$row_RCBangcap1 = $mydb->fetch_assoc($RCBangcap1);
$totalRows_RCBangcap1 = $mydb->num_rows($RCBangcap1);

// Lấy danh sách bằng cấp sau cập nhật
$mydb->setQuery("SELECT * FROM tlb_bangcap");
$RCBangcap = $mydb->executeQuery();
$row_RCBangcap = $mydb->fetch_assoc($RCBangcap);
$totalRows_RCBangcap = $mydb->num_rows($RCBangcap);

// Lấy danh sách ngoại ngữ hiện tại
$mydb->setQuery("SELECT * FROM tlb_ngoaingu inner join tlb_congviec on tlb_ngoaingu.ngoai_ngu_id = tlb_congviec.ngoai_ngu_id where tlb_congviec.ma_nhan_vien = '$ma_nv'");
$RCNgoaingu1 = $mydb->executeQuery();
$row_RCNgoaingu1 = $mydb->fetch_assoc($RCNgoaingu1);
$totalRows_RCNgoaingu1 = $mydb->num_rows($RCNgoaingu1);

// Lấy danh sách ngoại ngữ sau cập nhật
$mydb->setQuery("SELECT * FROM tlb_ngoaingu");
$RCNgoaingu = $mydb->executeQuery();
$row_RCNgoaingu = $mydb->fetch_assoc($RCNgoaingu);
$totalRows_RCNgoaingu = $mydb->num_rows($RCNgoaingu);

// Lấy danh sách trình độ tin học hiện tại
$mydb->setQuery("SELECT * FROM tlb_tinhoc inner join tlb_congviec on tlb_tinhoc.tin_hoc_id = tlb_congviec.tin_hoc_id where tlb_congviec.ma_nhan_vien = '$ma_nv'");
$RCTinhoc1 = $mydb->executeQuery();
$row_RCTinhoc1 = $mydb->fetch_assoc($RCTinhoc1);
$totalRows_RCTinhoc1 = $mydb->num_rows($RCTinhoc1);


// Lấy danh sách tin học sau khi cập nhật
$mydb->setQuery("SELECT * FROM tlb_tinhoc");
$RCTinhoc = $mydb->executeQuery();
$row_RCTinhoc = $mydb->fetch_assoc($RCTinhoc);
$totalRows_RCTinhoc = $mydb->num_rows($RCTinhoc);


?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Untitled Document</title>
    <style type="text/css">
        <!--
        body,td,th {
         font-family: Arial, Helvetica, sans-serif;
         font-size: 12px;
         line-height: 1.4;
     }
 -->
</style></head>
<body text="#000000" link="#CC0000" vlink="#0000CC" alink="#000099">
    <form action="<?php echo $editFormAction; ?>" method="post" name="form1" id="form1">
      <table class="row2" width="800" align="center" cellpadding="1" cellspacing="1" bgcolor="#66CCFF">
        <tr valign="baseline">
          <td width="102" align="right" nowrap="nowrap">Mã nhân viên:</td>
          <td width="219"><?php echo $row_RCcapnhat_congviec['ma_nhan_vien']; ?></td>
          <td width="110">Tài khoản NH:</td>
          <td width="291"><input type="text" name="tknh" value="<?php echo htmlentities($row_RCcapnhat_congviec['tknh'], ENT_COMPAT, 'utf-8'); ?>" size="32" /></td>
      </tr>
      <tr valign="baseline">
          <td nowrap="nowrap" align="right">Ngày vào làm *:</td>
          <td><input type="text" name="ngay_vao_lam" value="<?php echo htmlentities($row_RCcapnhat_congviec['ngay_vao_lam'], ENT_COMPAT, 'utf-8'); ?>" size="25" /></td>
          <td>Ngân hàng:</td>
          <td><input type="text" name="ngan_hang" value="<?php echo htmlentities($row_RCcapnhat_congviec['ngan_hang'], ENT_COMPAT, 'utf-8'); ?>" size="32" /></td>
      </tr>
      <tr valign="baseline">
          <td nowrap="nowrap" align="right">Phòng ban:</td>
          <td><select name="phong_ban_id">
              <option selected="selected" value="<?php echo $row_RCphongban1['phong_ban_id']?>"><?php echo $row_RCphongban1['ten_phong_ban']?></option>
              <?php 
              do {  
                ?>
                <option value="<?php echo $row_RCphongban['phong_ban_id']?>"><?php echo $row_RCphongban['ten_phong_ban']?></option>
                <?php
            } while ($row_RCphongban = mysql_fetch_assoc($RCphongban));
            ?>
        </select></td>
        <td>Học vấn:</td>
        <td><select name="hoc_van_id">
          <option selected="selected" value="<?php echo $row_RCHocvan1['hoc_van_id']?>"><?php echo $row_RCHocvan1['ten_hoc_van']?></option>
          <?php 
          do {  
            ?>
            <option value="<?php echo $row_RCHocvan['hoc_van_id']?>"><?php echo $row_RCHocvan['ten_hoc_van']?></option>
            <?php
        } while ($row_RCHocvan = mysql_fetch_assoc($RCHocvan));
        ?>
    </select></td>
</tr>
<tr valign="baseline">
  <td nowrap="nowrap" align="right">Công việc:</td>
  <td><select name="cong_viec_id">
      <option selected="selected" value="<?php echo $row_RCctcongviec1['cong_viec_id']?>"><?php echo $row_RCctcongviec1['ten_cong_viec']?></option>
      <?php 
      do {  
        ?>
        <option value="<?php echo $row_RCctcongviec['cong_viec_id']?>"><?php echo $row_RCctcongviec['ten_cong_viec']?></option>
        <?php
    } while ($row_RCctcongviec = mysql_fetch_assoc($RCctcongviec));
    ?>
</select></td>
<td>Bằng cấp:</td>
<td><select name="bang_cap_id">
  <option selected="selected" value="<?php echo $row_RCBangcap1['bang_cap_id']?>"><?php echo $row_RCBangcap1['ten_bang_cap']?></option>
  <?php 
  do {  
    ?>
    <option value="<?php echo $row_RCBangcap['bang_cap_id']?>"><?php echo $row_RCBangcap['ten_bang_cap']?></option>
    <?php
} while ($row_RCBangcap = mysql_fetch_assoc($RCBangcap));
?>
</select></td>
</tr>
<tr valign="baseline">
  <td nowrap="nowrap" align="right">Chức vụ:</td>
  <td><select name="chuc_vu_id">
      <option selected="selected" value="<?php echo $row_RCChucvu1['chuc_vu_id']?>"><?php echo $row_RCChucvu1['ten_chuc_vu']?></option>
      <?php 
      do {  
        ?>
        <option value="<?php echo $row_RCChucvu['chuc_vu_id']?>"><?php echo $row_RCChucvu['ten_chuc_vu']?></option>
        <?php
    } while ($row_RCChucvu = mysql_fetch_assoc($RCChucvu));
    ?>
</select></td>
<td>Ngoại ngữ:</td>
<td><select name="ngoai_ngu_id">
  <option selected="selected" value="<?php echo $row_RCNgoaingu1['ngoai_ngu_id']?>"><?php echo $row_RCNgoaingu1['ten_ngoai_ngu']?></option>
  <?php 
  do {  
    ?>
    <option value="<?php echo $row_RCNgoaingu['ngoai_ngu_id']?>"><?php echo $row_RCNgoaingu['ten_ngoai_ngu']?></option>
    <?php
} while ($row_RCNgoaingu = mysql_fetch_assoc($RCNgoaingu));
?>
</select></td>
</tr>
<tr valign="baseline">
  <td nowrap="nowrap" align="right">Mức lương:</td>
  <td><input type="text" name="muc_luong_cb" value="<?php echo htmlentities($row_RCcapnhat_congviec['muc_luong_cb'], ENT_COMPAT, 'utf-8'); ?>" size="32" /></td>
  <td>Tin học:</td>
  <td><select name="tin_hoc_id">
      <option selected="selected" value="<?php echo $row_RCTinhoc1['tin_hoc_id']?>"><?php echo $row_RCTinhoc1['ten_tin_hoc']?></option>
      <?php 
      do {  
        ?>
        <option value="<?php echo $row_RCTinhoc['tin_hoc_id']?>"><?php echo $row_RCTinhoc['ten_tin_hoc']?></option>
        <?php
    } while ($row_RCTinhoc = mysql_fetch_assoc($RCTinhoc));
    ?>
</select></td>
</tr>
<tr valign="baseline">
  <td nowrap="nowrap" align="right">Hệ số:</td>
  <td><input type="text" name="he_so" value="<?php echo htmlentities($row_RCcapnhat_congviec['he_so'], ENT_COMPAT, 'utf-8'); ?>" size="32" /></td>
  <td></td>
  <td></td>
</tr>
<tr valign="baseline">
  <td nowrap="nowrap" align="right">Phụ cấp:</td>
  <td><input type="text" name="phu_cap" value="<?php echo htmlentities($row_RCcapnhat_congviec['phu_cap'], ENT_COMPAT, 'utf-8'); ?>" size="32" /></td>
  <td></td>
  <td></td>
</tr>
<tr valign="baseline">
  <td nowrap="nowrap" align="right">Số sổ lao động:</td>
  <td><input type="text" name="so_sld" value="<?php echo htmlentities($row_RCcapnhat_congviec['so_sld'], ENT_COMPAT, 'utf-8'); ?>" size="32" /></td>
  <td></td>
  <td></td>
</tr>
<tr valign="baseline">
  <td nowrap="nowrap" align="right">Ngày cấp:</td>
  <td><input type="text" name="ngay_cap" value="<?php echo htmlentities($row_RCcapnhat_congviec['ngay_cap'], ENT_COMPAT, 'utf-8'); ?>" size="32" /></td>
  <td></td>
  <td></td>
</tr>
<tr valign="baseline">
  <td nowrap="nowrap" align="right">Nơi cấp:</td>
  <td><input type="text" name="noi_cap" value="<?php echo htmlentities($row_RCcapnhat_congviec['noi_cap'], ENT_COMPAT, 'utf-8'); ?>" size="32" /></td>
  <td>&nbsp;</td>
  <td>&nbsp;</td>
</tr>
<tr valign="baseline">
  <td nowrap="nowrap" align="right">&nbsp;</td>
  <td>&nbsp;</td>
  <td>&nbsp;</td>
  <td>&nbsp;</td>
</tr>
<tr valign="baseline">
  <td colspan="4" align="center" nowrap="nowrap"><input type="submit" value=":|: Cập nhật :|:" /></td>
</tr>
</table>
<input type="hidden" name="MM_update" value="form1" />
<input type="hidden" name="ma_nhan_vien" value="<?php echo $row_RCcapnhat_congviec['ma_nhan_vien']; ?>" />
</form>
<p>&nbsp;</p>
</body>
</html>
<?php
mysql_free_result($RCcapnhat_congviec);
?>