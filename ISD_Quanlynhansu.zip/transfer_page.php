<HTML>
<HEAD>
<TITLE>Please stand by ...</TITLE>
<head>
<meta http-equiv="Content-Language" content="en-us">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="REFRESH" content="3; url=<?=$page_transfer?>">
<style type="text/css">
a {
	color:#122c56;
	text-decoration: none;
	font-family: Arial, Helvetica, sans-serif;
}

a:active {
	color:#122c56;
}

a:visited {
	color:#122c56;
}

a:hover {
	color:#FFFFFF;
}
</style>
</HEAD>
<BODY>
	<br/><br/><br/>
  	<center>
  	<table border="1" width="350" cellspacing="0" bordercolor="#CBE2EB" bgcolor="#d0e2f1">
	    <tr>
	      	<td width="350" align="center"><br/><font face="Arial" size="2" color="#122c56"><b>
			<?=$showtext?></b></font><br><br>PHU THANH VALVE ADMIN PANEL
										<br>Powered by GhoSter..,Inc<br><br>
			<a href="<?=$page_transfer?>">Click v&#224;o &#273;&#226;y n&#7871;u b&#7841;n kh&#244;ng mu&#7889;n &#273;&#7907;i l&#226;u !</a>
			</td>
	    </tr>
  	</table>
  	</center>
</BODY>
<HTML>